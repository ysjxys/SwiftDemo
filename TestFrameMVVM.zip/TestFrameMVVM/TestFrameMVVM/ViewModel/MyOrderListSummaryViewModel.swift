//
//  MyOrderListSummaryViewModel.swift
//  TestFrameMVVM
//
//  Created by ysj on 2017/12/27.
//  Copyright © 2017年 ysj. All rights reserved.
//

import Foundation

struct MyOrderListSummaryViewModel {
    //外部传入model
    var orderArray: [MyOrderListModel]
    
    //viewModel内部参数
    var orderSummaryIncome: Double
    var orderCount: Int
    
    init(array: [MyOrderListModel]) {
        orderArray = array
        
        orderSummaryIncome = 0.0
        orderCount = 0
        
        updateListModel(array: array)
    }
    
    mutating func updateListModel(array: [MyOrderListModel]) {
        self.orderArray = array
        
        orderSummaryIncome = updateOrderSummaryIncome()
        orderCount = updateOrderCount()
        
    }
    
    func updateOrderCount() -> Int {
        return orderArray.count
    }
    
    func updateOrderSummaryIncome() -> Double {
        var summary: Double = 0.0
        for model in orderArray {
            summary = summary + (model.payAmount ?? 0.0)
        }
        return summary
    }
}
