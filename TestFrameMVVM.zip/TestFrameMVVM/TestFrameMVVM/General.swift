//
//  General.swift
//  TestFrameMVVM
//
//  Created by ysj on 2017/12/27.
//  Copyright © 2017年 ysj. All rights reserved.
//

import Foundation
import Vine

typealias HttpRequest = Vine.HttpRequest
typealias HTTPMethod = Vine.HTTPMethod
typealias Modeling = Vine.Modeling
typealias DataSource = Vine.DataSource
typealias NothingModel = Vine.NothingModel
typealias HttpAPI = Vine.HttpClient
