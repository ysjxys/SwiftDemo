//
//  ViewController.swift
//  TestFrameMVVM
//
//  Created by ysj on 2017/12/27.
//  Copyright © 2017年 ysj. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var summaryView = MyOrderListSummaryView()
    
    //update viewModel层   可不持有
    var orderArray: [MyOrderListModel] = [] {
        didSet {
            viewModel.updateListModel(array: orderArray)
            
        }
    }
    
    //update View层
    var viewModel: MyOrderListSummaryViewModel = MyOrderListSummaryViewModel(array: []) {
        didSet {
            summaryView.updateViewModel(viewModel: viewModel)
            summaryView.tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(summaryView)
        summaryView.tableView.delegate = self
        summaryView.tableView.dataSource = self
        
        loadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func loadData() {
        MyOrderService.getOrderListWith(pageNo: 1, pageSize: 10, taskStatus: 2, successed: { (response) in
            guard let list = response.list else {
                return
            }
            self.orderArray = list
        }) { (error) in
            print("error")
        }
    }
    
    // MARK: - tableView DataSource & Delegate method
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(50)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orderArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = OrderListTableViewCell.cell(tableView: tableView)
        let cellViewModel = OrderListTableViewCellViewModel(listModel: orderArray[indexPath.row])
        cell.updateViewModel(viewModel: cellViewModel)
        return cell
    }
}

