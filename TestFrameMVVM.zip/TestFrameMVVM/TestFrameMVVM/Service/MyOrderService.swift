//
//  MyOrderService.swift
//  TestFrameMVVM
//
//  Created by ysj on 2017/12/27.
//  Copyright © 2017年 ysj. All rights reserved.
//

import Foundation

class MyOrderService {
    private init() {}
    
    static func getOrderListWith(pageNo: Int, pageSize: Int, taskStatus: Int, successed: @escaping (MyOrderListArrayModel) -> Void, failed: @escaping (Error) -> Void) {
        HttpAPI.send(res: MyOrderListRequest(pageNo: pageNo, pageSize: pageSize, taskStatus: taskStatus, taskType: "M_SMALL_ORDER")) {
            
            switch $0 {
            case .success(let model):
                successed(model)
            case .failure(let error):
                failed(error)
            }
        }
    }
    
}
